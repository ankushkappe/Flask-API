import requests

# URL of the Flask application
url = "http://127.0.0.1:5000/countries"

# New country data
new_country = {
    "name": "New Country",
    "capital": "New Capital",
    "area": 1000000
}

# Send a POST request to add the new country
response = requests.post(url, json=new_country)

# Print the response status code
print("Response status code:", response.status_code)

# Print the response content (newly added country)
print("Newly added country:")
print(response.json())
