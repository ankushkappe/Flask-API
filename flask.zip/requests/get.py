import requests

# URL of the Flask application
url = "http://127.0.0.1:5000/countries"

# Send a GET request to fetch the list of countries
response = requests.get(url)

# Print the response status code
print("Response status code:", response.status_code)

# Print the response content (list of countries)
print("List of countries:")
print(response.json())
